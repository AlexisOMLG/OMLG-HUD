-----------------------------------------------------------------
--            CE FICHIER PERMET LA MODIFICATION DU SCRIPT      --
--            THIS FILE ALLOWS THE MODIFICATION OF THE SCRIPT  --
-----------------------------------------------------------------
CONFIG = {}

CONFIG.BASICCOLOR = Color(0,0,0,255) -- Couleur de fond derrière les barres (Noir par défaut)

CONFIG.HEALTHCOLOR = Color(189,24,24,255) -- Couleur pour la barre de vie

CONFIG.ARMORCOLOR = Color(0,102,255,255) -- Couleur pour la barre d'armure

CONFIG.TEXTBAR = Color(255,255,255,255) -- Couleur du texte sur le barre de vie/armure.

CONFIG.SALARYCOLOR = Color(199,223,2,255) -- Couleur du texte pour le salaire.

CONFIG.MONEYCOLOR = Color(50,221,10,255) -- Couleur du texte pour l'argent du joueur.

CONFIG.NAMECOLOR = Color(255,255,255,255) -- Couleur du texte pour le nom Roleplay du joueur.

CONFIG.FOODTEXT = Color(255,255,255,255) -- Couleur du texte pour la faim.